---
date: 19Jul26
title: Dynamic Programming — Complete CSES Revision Notes
---

# Dynamic Programming

---

## 1. Dice Combinations

### Problem Statement & Core Idea
Count the number of ordered ways to construct a target sum $n$ by rolling a standard $6$-sided die ($a_i \in \{1, 2, 3, 4, 5, 6\}$) repeatedly.

![Dice Combinations Concept](images/01_dice_combinations.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i) = \text{number of ordered ways to form sum } i$$

- **Base Cases**:
  $$f(0) = 1, \qquad f(i) = 0 \quad \forall\, i < 0$$

- **State Transition**:
  $$f(i) = \left( \sum_{\text{throw}=1}^{6} f(i - \text{throw}) \right) \bmod (10^9 + 7)$$

- **Evaluation Order & Complexity**: Compute $i = 1, 2, \dots, n$ in $\mathcal{O}(n)$ time and $\mathcal{O}(n)$ space.

---

## 2. Min Coins

### Problem Statement & Core Idea
Find the minimum number of coins from a given set $\mathcal{C} = \{c_1, c_2, \dots, c_n\}$ (with unlimited repetition) required to form sum $x$.

![Min Coins Concept](images/02_min_coins.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i) = \text{minimum number of coins needed to form sum } i$$

- **Base Cases**:
  $$f(0) = 0, \qquad f(i) = +\infty \quad \text{for } i < 0 \text{ (and unreachable sums)}$$

- **State Transition**:
  $$f(i) = 1 + \min_{c \in \mathcal{C},\; i - c \ge 0} f(i - c)$$

### Implementation Tricks
- **Sort for Early Break**: Sort the coin denominations in ascending order ($c_1 < c_2 < \dots < c_n$) beforehand so that inside the inner coin loop, as soon as `coin > i`, you can `break` early because all subsequent coins are also too large.

---

## 3. Coin Combinations 1

### Problem Statement & Core Idea
Count the number of **ordered** ways (permutations) to form sum $n$ using coins from $\mathcal{C} = \{c_1, \dots, c_k\}$.
- Here, $1 + 2$ and $2 + 1$ are counted as **distinct** sequences, just like in *Dice Combinations*.

![Coin Combinations 1 Concept](images/03_coin_combinations_1.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i) = \text{number of ordered ways to make sum } i$$

- **Base Cases**:
  $$f(0) = 1, \qquad f(i) = 0 \quad \forall\, i < 0$$

- **State Transition** *(Outer loop over target sum $i$, inner loop over coin $c$)*:
  $$f(i) = \left( \sum_{c \in \mathcal{C},\; i - c \ge 0} f(i - c) \right) \bmod (10^9 + 7)$$

---

## 4. Coin Combinations 2

### Problem Statement & Core Idea
Count the number of **unordered** combinations to form sum $n$ using coins from $\mathcal{C} = \{c_1, \dots, c_k\}$.
- Here, $1 + 2$ is treated as the **exact same** combination as $2 + 1$.
- **Core Idea**: Sort coins (optional but good practice) and **loop over coins in the outer loop**, updating sums in ascending order in the inner loop so coins are always appended in non-decreasing index order.

![Coin Combinations 2 Concept](images/04_coin_combinations_2.png)

### Formal DP Formulation

- **State Definition**:
  $$f(x) = \text{number of unordered combinations to make sum } x \text{ (using coins processed so far)}$$

- **Base Case**:
  $$f(0) = 1, \qquad f(x) = 0 \quad \forall\, x > 0 \text{ initially}$$

- **State Transition** *(For each coin $c \in \mathcal{C}$, for $x = c, c+1, \dots, n$ ascending)*:
  $$f(x) \mathrel{+}= f(x - c) \pmod{10^9 + 7}$$

> Explicitly in 2D notation, if $f(k, x)$ is the number of ways using the first $k$ coins:
> $$f(k, x) = f(k - 1, x) + \begin{cases} f(k, x - c_k) & \text{if } x \ge c_k \\ 0 & \text{otherwise} \end{cases}$$

---

## 5. Removing Digits

### Problem Statement & Core Idea
Given an integer $n$, in each step subtract one of the non-zero base-$10$ digits present in $n$. Find the minimum number of steps to reduce $n$ to $0$.
- *Initial thought*: Can this be done iteratively? Yes, because $i - d < i$ for every non-zero digit $d$, so all dependencies for $f(i)$ are strictly smaller than $i$.

![Removing Digits Concept](images/05_removing_digits.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i) = \text{minimum steps required to reduce } i \text{ to } 0$$

- **Base Case**:
  $$f(0) = 0$$

- **State Transition**:
  $$f(i) = 1 + \min_{d \in \text{digits}(i),\; d > 0} f(i - d)$$

- **Evaluation Order**: Compute $f(i)$ iteratively for $i = 1, 2, \dots, n$.

### Alternative Greedy Solution & Proof of Correctness
- **Greedy Idea**: Always subtract the largest digit $d(i) = \max(\text{digits}(i))$ because $f(i)$ is monotonically non-decreasing ($f(0) < f(1) \le f(2) \le \dots$).
- **Proof by Induction**:
  - **Base**: $f(0) = 0 < f(1) = 1 \le f(2) = 1$.
  - **Inductive Step**: Assume $f(0) \le f(1) \le \dots \le f(k)$. When moving from $i$ to $i + 1$:
    - *Example 1*: $24 \to 25$: largest digit increases by $1$ ($4 \to 5$), so next state is $25 - 5 = 20 = 24 - 4$.
    - *Example 2*: $29 \to 30$: largest digit drops ($9 \to 3$), so next state jumps forward ($30 - 3 = 27 > 29 - 9 = 20$).
  - Let $d(i)$ denote the largest digit of $i$. Because incrementing an integer by $1$ can increase its maximum digit by at most $1$:
    $$d(i + 1) \le d(i) + 1 \implies (i + 1) - d(i + 1) \ge i - d(i)$$
  - Thus, the greedy transition target $i - d(i)$ is non-decreasing in $i$. By induction, $f(i)$ is non-decreasing, so subtracting the largest digit $d(i)$ reaches the smallest possible state and is globally optimal.

---

## 6. Grid Paths

### Problem Statement & Core Idea
Given an $n \times n$ grid with some blocked cells (`*`), count the number of paths from the top-left $(0, 0)$ to the bottom-right $(n-1, n-1)$ moving only right or down.

![Grid Paths Concept](images/06_grid_paths.png)

### Formal DP Formulation

- **State Definition**:
  $$f(r, c) = \text{number of valid paths from } (0, 0) \text{ to } (r, c)$$

- **Base Case**:
  $$f(0, 0) = \begin{cases} 1 & \text{if grid}[0][0] = \text{'.'} \\ 0 & \text{if grid}[0][0] = \text{'*'} \end{cases}$$

- **State Transition**:
  $$f(r, c) = \begin{cases} 0 & \text{if grid}[r][c] = \text{'*'} \\ \big(f(r - 1, c) + f(r, c - 1)\big) \bmod (10^9 + 7) & \text{otherwise} \end{cases}$$
  *(treating out-of-bounds indices $r < 0$ or $c < 0$ as $0$).*

---

## 7. Bookshop

### Problem Statement & Core Idea
Standard **$0/1$ Knapsack** (single-use items): given $n$ books each with price (weight) $\text{wt}_i$ and pages (value) $\text{val}_i$, maximize total pages subject to total price $\le W$.
- *Complexity Note*: $\mathcal{O}(nW) \approx 10^8$ operations with simple array updates easily passes within the time limit in C++.

![Bookshop Concept](images/07_bookshop.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, w) = \text{maximum value achievable using a subset of the first } i \text{ items with total weight } \le w$$

- **Base Case**:
  $$f(0, w) = 0 \quad \forall\, w \in [0, W]$$

- **State Transition**:
  $$f(i, w) = \begin{cases} \max\big(f(i - 1, w),\; \text{val}_i + f(i - 1, w - \text{wt}_i)\big) & \text{if } w - \text{wt}_i \ge 0 \\ f(i - 1, w) & \text{if } w < \text{wt}_i \end{cases}$$

- **Implementation Trick (1D Rolling Array)**: Maintain a single 1D array `dp[0..W]` and iterate $j$ **from right to left** ($j = W$ down to $\text{wt}_i$) so `dp[j - w]` still holds the value from iteration $i - 1$ (preventing an item from being picked multiple times).

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, W;
    cin >> n >> W;

    vector<int> wt(n), val(n);
    for (int &x : wt)
        cin >> x;
    for (int &x : val)
        cin >> x;

    vector<int> dp(W + 1, 0);
    for (int i = 0; i < n; i++) {
        int w = wt[i], v = val[i];
        for (int j = W; j >= w; j--) {
            dp[j] = max(dp[j], dp[j - w] + v);
        }
    }

    cout << dp[W] << "\n";

    return 0;
}
```

---

## 8. Array Description

### Problem Statement & Core Idea
Given an array $a_1, a_2, \dots, a_n$ where $a_i \in \{0, 1, \dots, m\}$ ($m \le 100$) and $a_i = 0$ denotes an unknown value that can be replaced by any integer in $\{1, \dots, m\}$, count the number of valid arrays satisfying $\lvert a_i - a_{i+1} \rvert \le 1$ for all $1 \le i < n$.

![Array Description Concept](images/08_array_description.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, j) = \text{number of valid ways to fill the prefix } a[1..i] \text{ such that } a_i = j$$

- **Base Case** ($i = 1$, for $j \in \{1, \dots, m\}$):
  $$f(1, j) = \begin{cases} 1 & \text{if } a_1 = 0 \text{ or } a_1 = j \\ 0 & \text{otherwise} \end{cases}$$

- **State Transition** ($i = 2, \dots, n$, for $j \in \{1, \dots, m\}$):
  $$f(i, j) = \begin{cases} \displaystyle\sum_{k = \max(1,\, j-1)}^{\min(m,\, j+1)} f(i - 1, k) \pmod{10^9 + 7} & \text{if } a_i = 0 \text{ or } a_i = j \\ 0 & \text{otherwise} \end{cases}$$

- **Optimizations**:
  - *Active Window Optimization*: Track the reachable interval $[L_i, R_i]$ around fixed values to speed up average-case runtime (same $\mathcal{O}(nm)$ worst case).
  - *Sparse Zero-Segment Optimization*: Long contiguous blocks of zeroes can be jumped via matrix exponentiation or polynomial/combinatorial transitions.

---

## 9. Counting Towers

### Problem Statement & Core Idea
Given an unlimited supply of integer-dimension rectangular blocks, count the number of ways to build a tower of height $h$ and width $2$.

![Counting Towers Concept](images/09_counting_towers.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, s) = \text{number of ways to build a flat-topped tower of height } i \text{ in state } s \in \{0, 1\}$$
  where:
  - $s = 0$ (**Joined**): the $i$-th row consists of a single unified $1 \times 2$ horizontal layer.
  - $s = 1$ (**Broken**): the $i$-th row consists of two independent $1 \times 1$ vertical columns (left and right).

- **Base Case**:
  $$f(1, 0) = 1, \qquad f(1, 1) = 1$$

- **Combinatorial Transition Derivation**:
  - **From Joined ($s = 0$) at height $i - 1$**:
    - Close the block and start a new *broken* split at row $i$ $\longrightarrow$ contributes $f(i-1, 0)$ to $s = 1$.
    - Close the block and start a new *joined* block at row $i$ $\longrightarrow$ contributes $f(i-1, 0)$ to $s = 0$.
    - Extend the existing *joined* block upward into row $i$ $\longrightarrow$ contributes $f(i-1, 0)$ to $s = 0$.
  - **From Broken ($s = 1$) at height $i - 1$**:
    - Close both columns and start a new *joined* block $\longrightarrow$ contributes $f(i-1, 1)$ to $s = 0$.
    - Close both columns and start a new *broken* split $\longrightarrow$ contributes $f(i-1, 1)$ to $s = 1$.
    - Extend only the left column, only the right column, or both columns independently $\longrightarrow$ contributes $3 \cdot f(i-1, 1)$ to $s = 1$.

- **Matrix / Linear Recurrence**:
  $$\begin{aligned}
  f(i, 0) &= \big(2\,f(i - 1, 0) + f(i - 1, 1)\big) \bmod (10^9 + 7) \\
  f(i, 1) &= \big(f(i - 1, 0) + 4\,f(i - 1, 1)\big) \bmod (10^9 + 7)
  \end{aligned}$$
  **Total Answer for height $n$**: $\big(f(n, 0) + f(n, 1)\big) \bmod (10^9 + 7)$.

---

## 10. Edit Distance

### Problem Statement & Core Idea
Compute the minimum number of operations (delete a character from $a$, delete a character from $b$, or replace a character) required to transform string $a$ into string $b$.

![Edit Distance Concept](images/10_edit_distance.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, j) = \text{minimum edit distance between prefix } a[0..i-1] \text{ (length } i\text{) and prefix } b[0..j-1] \text{ (length } j\text{)}$$

- **Base Cases**:
  $$f(0, j) = j \quad \forall\, j \in [0, m], \qquad f(i, 0) = i \quad \forall\, i \in [0, n]$$

- **State Transition**:
  $$f(i, j) = \min \begin{cases}
  1 + f(i - 1, j) & \text{(delete } a[i-1]\text{)} \\
  1 + f(i, j - 1) & \text{(delete } b[j-1]\text{ / insert into } a\text{)} \\
  f(i - 1, j - 1) + \mathbf{1}[a[i - 1] \ne b[j - 1]] & \text{(match or replace)}
  \end{cases}$$

---

## 11. LCS (Longest Common Subsequence)

### Problem Statement & Core Idea
Calculate the length of the longest common subsequence of two sequences $a$ and $b$, and reconstruct the actual subsequence by walking backward through the 2D DP table.

![LCS Concept](images/11_lcs.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, j) = \text{length of the LCS of prefixes } a[0..i-1] \text{ and } b[0..j-1]$$

- **Base Cases**:
  $$f(i, 0) = 0 \quad \forall\, i, \qquad f(0, j) = 0 \quad \forall\, j$$

- **State Transition**:
  $$f(i, j) = \begin{cases}
  1 + f(i - 1, j - 1) & \text{if } a[i - 1] = b[j - 1] \\
  \max\big(f(i - 1, j),\; f(i, j - 1)\big) & \text{if } a[i - 1] \ne b[j - 1]
  \end{cases}$$

- **Backtracking Reconstruction**: Start at $(n, m)$. If $a[n-1] = b[m-1]$, record $a[n-1]$ and step diagonally to $(n-1, m-1)$; otherwise move to whichever neighbor $(n-1, m)$ or $(n, m-1)$ preserves the larger DP value. Reverse the collected elements at the end.

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define in long long
    int n, m;
    cin >> n >> m;
    vector<int> a(n), b(m);
    for (int &x : a)
        cin >> x;
    for (int &x : b)
        cin >> x;
    vector<vector<in>> dp(n + 1, vector<in>(m + 1, 0));

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (a[i - 1] == b[j - 1]) {
                dp[i][j] = 1 + dp[i - 1][j - 1];
            } else {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    cout << dp[n][m] << "\n";

    vector<int> ans;
    while (dp[n][m] > 0) {
        if (a[n - 1] == b[m - 1]) {
            ans.push_back(a[n - 1]);
            n--;
            m--;
        } else if (dp[n - 1][m] > dp[n][m - 1]) {
            n--;
        } else {
            m--;
        }
    }
    reverse(ans.begin(), ans.end());
    for (int x : ans)
        cout << x << " ";
    cout << "\n";
#undef int
}
```

---

## 12. Rectangle Cutting

### Problem Statement & Core Idea
Given an $a \times b$ rectangle, in each move cut a rectangle completely along an integer horizontal or vertical line into two smaller rectangles. Find the minimum number of cuts so every resulting piece is a square.
- **Complexity**: $\mathcal{O}(ab(a + b))$, which is $\mathcal{O}(n^3)$ when $a, b = \mathcal{O}(n)$.

![Rectangle Cutting Concept](images/12_rectangle_cutting.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, j) = \text{minimum cuts required to partition an } i \times j \text{ rectangle into squares}$$

- **Base Cases**:
  $$f(i, i) = 0 \quad \forall\, i \ge 1 \quad (\text{already a square; initialize non-square states to }+\infty)$$

- **State Transition** (for $i \ne j$):
  $$f(i, j) = \min \left\{ \min_{1 \le k < i} \big(f(k, j) + f(i - k, j) + 1\big),\; \min_{1 \le k < j} \big(f(i, k) + f(i, j - k) + 1\big) \right\}$$

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n, m;
    cin >> n >> m;
    const int inf = (int)1e18;
    vector<vector<int>> dp(n + 1, vector<int>(m + 1, 0));

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (i == j) {
                dp[i][j] = 0;
            } else {
                dp[i][j] = inf;
                for (int k = 1; k < i; k++) {
                    dp[i][j] = min(dp[i][j], dp[k][j] + dp[i - k][j] + 1);
                }
                for (int k = 1; k < j; k++) {
                    dp[i][j] = min(dp[i][j], dp[i][k] + dp[i][j - k] + 1);
                }
            }
        }
    }
    cout << dp[n][m] << "\n";

#undef int
}
```

---

## 13. Minimal Grid Path

### Problem Statement & Core Idea
Given an $n \times n$ grid of uppercase characters, find the lexicographically smallest string formed along a path from top-left $(0, 0)$ to bottom-right $(n-1, n-1)$ moving only right or down.
- **Greedy / Level-Synchronous BFS DP**: Every path has exact length $2n - 1$. Maintain the active frontier `candidates` at step $d$. At each step:
  1. Find the minimum character $\text{mn} = \min_{(x, y) \in \text{candidates}} v[x][y]$.
  2. Output $\text{mn}$ and expand **only** those candidates $(x, y)$ where $v[x][y] = \text{mn}$.
- **Two Implementation Tricks**:
  1. **Visit Order (Right then Down)**: Expanding `(0, +1)` before `(+1, 0)` across a row-sorted frontier naturally produces `new_candidates` in sorted coordinate order.
  2. **$\mathcal{O}(1)$ In-Place Deduplication**: Because `new_candidates` is generated in sorted order, duplicate cells are adjacent and can be filtered simply by checking `new_candidates.back() != make_pair(nx, ny)`.

![Minimal Grid Path Concept](images/13_minimal_grid_path.png)

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n;
    cin >> n;
    vector<string> v(n);
    for (auto &x : v)
        cin >> x;

    vector<pair<int, int>> candidates, new_candidates;
    candidates.push_back({0, 0});

    // order matters, right then down makes (0,0)->(0,1)->(1,1)->(1,2) which is
    // sorted
    vector<int> dx = {0, 1};
    vector<int> dy = {1, 0};

    int steps = 2 * n - 1;
    while (steps--) {
        char mn = 'Z' + 1;
        int sz = (int)candidates.size();
        for (auto &[x, y] : candidates) {
            mn = min(mn, v[x][y]);
        }

        cout << mn;

        new_candidates.clear();
        for (auto &[x, y] : candidates) {
            if (v[x][y] != mn)
                continue;
            for (int dir = 0; dir < 2; dir++) {
                int nx = x + dx[dir];
                int ny = y + dy[dir];
                if (nx < n && ny < n &&
                    (new_candidates.empty() ||
                     new_candidates.back() != make_pair(nx, ny))) {
                    new_candidates.push_back({nx, ny});
                }
                // at each step there can be too many duplicates so filter those
            }
        }

        swap(candidates, new_candidates);
    }
    cout << '\n';

#undef int
}
```

---

## 14. Money Sums

### Problem Statement & Core Idea
Given $n$ coins ($n \le 100$, each $v_i \le 1000$), find all distinct positive sums that can be formed using subsets of the coins.

![Money Sums Concept](images/14_money_sums.png)

### Formal DP Formulation

- **State Definition**:
  $$f(s) \in \{0, 1\} = \text{whether sum } s \text{ is achievable}$$

- **Base Case**:
  $$f(0) = 1, \qquad f(s) = 0 \quad \forall\, s > 0$$

- **State Transition** *(For each coin $\text{cur} \in v$, for $s = N-1$ down to $\text{cur}$)*:
  $$f(s) \mathrel{|}= f(s - \text{cur})$$

- **Further Extension**: Counting distinct ways or bounded knapsack where coins with identical values (e.g. `2 2 2`) only count unique frequency combinations toward sum `4`.

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n;
    cin >> n;
    vector<int> v(n);
    for (int &x : v)
        cin >> x;

    const int N = (int)1e5 + 5;
    vector<int> dp(N, 0);
    dp[0] = 1;

    int ans = 0;
    for (int cur : v) {
        for (int i = N - 1; i >= cur; i--) {
            if (dp[i - cur] && !dp[i])
                dp[i] = 1, ans++;
        }
    }

    cout << ans << "\n";
    for (int i = 1; i < N; i++) {
        if (dp[i]) {
            cout << i << " ";
        }
    }
    cout << "\n";

#undef int
}
```

---

## 15. Removal Game

### Problem Statement & Core Idea
Two players alternately remove either the first or last element of an array $v[0..n-1]$, adding it to their score. Both play optimally. Find the first player's final score.
- **Minimax Difference Trick**: Because the game is constant-sum ($S_1 + S_2 = \sum v_i$) with symmetric rules, maximizing your own score is equivalent to maximizing the net score difference $\Delta = S_{\text{current}} - S_{\text{other}}$.

![Removal Game Concept](images/15_removal_game.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i, j) = \max(\text{current player's score} - \text{opponent's score}) \text{ on subarray } v[i..j]$$

- **Base Case** ($	ext{len} = 1$):
  $$f(i, i) = v_i \quad \forall\, i \in [0, n - 1]$$

- **State Transition** (processed by increasing subarray length $\text{len} = 2, \dots, n$):
  $$f(i, j) = \max\big(v_i - f(i + 1, j),\; v_j - f(i, j - 1)\big)$$

- **Recovering First Player's Score**:
  $$\left\{ \begin{aligned} S_1 + S_2 &= \text{sum} \\ S_1 - S_2 &= f(0, n - 1) \end{aligned} \right. \implies S_1 = \frac{\text{sum} + f(0, n - 1)}{2}$$

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n;
    cin >> n;
    vector<int> v(n);
    for (int &x : v)
        cin >> x;

    vector<vector<int>> dp(n, vector<int>(n, 0));
    for (int i = 0; i < n; i++)
        dp[i][i] = v[i];
    for (int len = 2; len <= n; len++) {
        for (int i = 0; i <= n - len; i++) {
            int j = i + len - 1;
            dp[i][j] = max(v[i] - dp[i + 1][j], v[j] - dp[i][j - 1]);
        }
    }

    int ans = dp[0][n - 1];
    int sum = accumulate(v.begin(), v.end(), 0LL);
    cout << (sum + ans) / 2 << "\n";

#undef int
}
```

---

## 16. Two Sets 2

### Problem Statement & Core Idea
Count the number of ways to partition $\{1, 2, \dots, n\}$ into two sets of equal sum modulo $10^9 + 7$.

![Two Sets 2 Concept](images/16_two_sets_2.png)

### Formal DP Formulation

- **Parity Check (No-Solution Case)**:
  Let $S = \frac{n(n + 1)}{2}$. If $S \bmod 2 \ne 0$, output $0$ immediately. Otherwise, the target sum for each set is $T = \frac{S}{2}$.

- **State Definition**:
  $$f(i, s) = \text{number of subsets of } \{1, \dots, i\} \text{ that sum to } s$$

- **Base Case**:
  $$f(0, 0) = 1, \qquad f(0, s) = 0 \quad \forall\, s > 0$$

- **State Transition** (0/1 Subset Sum):
  $$f(i, s) = f(i - 1, s) + \begin{cases} f(i - 1, s - i) & \text{if } s \ge i \\ 0 & \text{otherwise} \end{cases}$$
  *(To avoid counting each partition $\{A, B\}$ twice, either iterate $i$ only up to $n - 1$ to fix element $n$ in the second set, or multiply $f(n, T)$ by $2^{-1} \bmod (10^9 + 7)$).*

---

## 17. Mountain Range

### Problem Statement & Core Idea
DP on a Cartesian Tree / Monotonic Stack DAG:
- **Processing Order**: Instead of left-to-right index order, we process elements **ordered by height**.
- **Method 1 (State Inversion)**: Jumping from a higher peak $u$ down to smaller peaks branches across many candidates. Instead, **invert the perspective**: start at a smaller peak $u$ and look to transition **upward** to the nearest strictly higher peak to the left ($\text{gt\_left}[u]$) or right ($\text{gt\_right}[u]$).
- **Method 2 (Cartesian Tree / DAG DP)**: Build the DAG where each node $u$ has at most two outgoing edges ($\text{gt\_left}[u]$ and $\text{gt\_right}[u]$) and run DP in topological order (decreasing height).

![Mountain Range Concept](images/17_mountain_range.png)

### Formal DP Formulation

- **State Definition**:
  $$\text{dp}(u) = \text{maximum chain length ending at index } u$$

- **Base Case**:
  $$\text{dp}(u) = 1 \quad \forall\, u \in [0, n - 1]$$

- **State Transition** *(Processed in decreasing order of height $h_u$)*:
  $$\text{dp}(u) = \max\Big(1,\; \underbrace{1 + \text{dp}(\text{gt\_left}[u])}_{\text{if gt\_left}[u] \ne -1},\; \underbrace{1 + \text{dp}(\text{gt\_right}[u])}_{\text{if gt\_right}[u] \ne -1}\Big)$$

- **Monotonic Stack Template**: Loop through elements $\to$ pop while stack top violates monotonicity $\to$ if stack non-empty, record nearest greater index $\to$ push current index.

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n;
    cin >> n;
    vector<pair<int, int>> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i].first;
        v[i].second = i;
    }

    auto mono_stack = [](const auto &arr, auto first, auto last, auto should_pop) {
        int n = arr.size();
        vector<int> res(n, -1);
        vector<int> st;

        for (auto it = first; it != last; ++it) {
            while (!st.empty() && should_pop(arr[st.back()].first, (*it).first)) {
                st.pop_back();
            }
            int i = &(*it) - arr.data();

            if (!st.empty())
                res[i] = st.back();
            st.push_back(i);
        }
        return res;
    };

    auto gt_left = mono_stack(v, v.begin(), v.end(), less_equal<int>());
    auto gt_right = mono_stack(v, v.rbegin(), v.rend(), less_equal<int>());

    sort(v.begin(), v.end(), greater<>());

    vector<int> ans(n, 1);
    for (auto [h, idx] : v) {
        if (gt_left[idx] != -1) {
            ans[idx] = max(ans[idx], 1 + ans[gt_left[idx]]);
        }
        if (gt_right[idx] != -1) {
            ans[idx] = max(ans[idx], 1 + ans[gt_right[idx]]);
        }
    }

    cout << *max_element(ans.begin(), ans.end()) << endl;

#undef int
}
```

---

## 18. Increasing Subsequence

### Problem Statement & Core Idea
Find the length of the Longest Increasing Subsequence (LIS) in $\mathcal{O}(n \log n)$ time using the **greedy tails array**.

![Increasing Subsequence Concept](images/18_increasing_subsequence.png)

### Formal DP Formulation

- **State Definition**:
  $$f(k) = \text{minimum ending element of an increasing subsequence of length } k + 1$$

- **Greedy Transition Rule** (upon scanning element $x$):
  Let $\text{pos}$ be the first index where $f(\text{pos}) \ge x$ (found via `std::lower_bound`):
  $$\begin{cases}
  \text{append } x \text{ to the end of } f & \text{if } x > f(\text{last}) \\
  f(\text{pos}) \leftarrow x & \text{otherwise (lowers tail of length } \text{pos}+1\text{)}
  \end{cases}$$

- **Change for Longest Non-Decreasing Subsequence**: Replace `lower_bound` ($\ge x$) with `upper_bound` ($> x$).

```c++
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n;
    cin >> n;
    vector<int> v(n);
    for (int &x : v)
        cin >> x;

    vector<int> lis;
    for (int x : v) {
        auto it = lower_bound(lis.begin(), lis.end(), x);
        if (it == lis.end()) {
            lis.push_back(x);
        } else {
            *it = x;
        }
    }

    cout << (int)lis.size() << "\n";
#undef int
}
```

---

## 19. Projects

### Problem Statement & Core Idea
Given $n$ projects with start time $a_i$, end time $b_i$, and reward $p_i$, find the maximum total money you can earn from mutually non-overlapping projects.
- **Prefix Maximum Optimization DP**: The standard recurrence is $f(j) = \max_{i < j,\; b_i < a_j} f(i) + p_j$.
- **Coordinate Compression / Event Sweep**: Sort all start and end endpoints as events `(time, project, is_end)`. Maintain `result` as the maximum profit among all projects that have already finished.

![Projects Concept](images/19_projects.png)

### Formal DP Formulation

- **Event-Driven Transition**:
  - **On Start Event** $(a_i, i, \text{false})$:
    $$\text{money}[i] = \text{result} + p_i$$
  - **On End Event** $(b_i, i, \text{true})$:
    $$\text{result} = \max(\text{result},\; \text{money}[i])$$

### Implementation Niceness

```c++
for (auto [time, project, is_end] : events) {
    if (is_end) {
        result = max(result, money[project]);
    } else {
        money[project] = result + p[project];
    }
}
```

---

## 20. Elevator Rides

### Problem Statement & Core Idea
Given $n$ people ($n \le 20$) with weights $v_0, \dots, v_{n-1}$ and elevator capacity $W$, find the minimum number of rides needed to transport everyone.
- **Naive Submask Iteration ($\mathcal{O}(3^n)$)**: Iterating over all submasks $s \subseteq m$:

```c++
for (int m = 0; m < (1 << N); ++m) {
    for (int s = m; s > 0; s = (s - 1) & m) {
        // empty subset is not here
    }
}
```

- **Optimizing to $\mathcal{O}(n \cdot 2^n)$ via Lexicographic Pair State**: For any subset of people $i \subseteq \{0, \dots, n-1\}$, greedily minimize the number of rides first, and break ties by minimizing the weight already loaded into the **current (last) ride**.

![Elevator Rides Concept](images/20_elevator_rides.png)

### Formal DP Formulation

- **State Definition**:
  $$f(\text{mask}) = (\text{rides},\; \text{last\_wt})$$
  representing the lexicographically minimum pair of $(\text{number of rides},\; \text{weight in the last ride})$ to transport subset $\text{mask}$.

- **Base Case**:
  $$f(0) = (1, 0), \qquad f(\text{mask}) = (+\infty, +\infty) \quad \forall\, \text{mask} > 0$$

- **State Transition** *(For each $\text{mask} \in [1, 2^n - 1]$ and each person $j$ with $((\text{mask} \gg j) \& 1) = 1$)*:
  Let $(r, w) = f(\text{mask} \oplus 2^j)$. Then:
  $$\text{candidate}(j) = \begin{cases}
  (r,\; w + v_j) & \text{if } w + v_j \le W \quad (\text{fits in current ride}) \\
  (r + 1,\; v_j) & \text{if } w + v_j > W \quad (\text{starts a new ride})
  \end{cases}$$
  $$f(\text{mask}) = \min_{j \in \text{mask}} \text{candidate}(j)$$

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n, w;
    cin >> n >> w;
    vector<int> v(n);
    for (int &x : v)
        cin >> x;

    const int INF = (int)1e18 + 5;
    vector<array<int, 2>> dp(1ll << n, {INF, INF});

    // f(i) = {min rides, min last ride wt}
    dp[0] = {1, 0}; // extend last keeping rides as 1

    for (int i = 1; i < (1ll << n); i++) {
        for (int j = 0; j < n; j++) {
            // skip if unset
            if (!((i >> j) & 1))
                continue;

            auto prev = dp[i ^ (1ll << j)];
            if (prev[1] + v[j] <= w) {
                // no new ride
                dp[i] = min(dp[i], {prev[0], prev[1] + v[j]});
            } else {
                dp[i] = min(dp[i], {prev[0] + 1, v[j]});
            }
        }
    }

    cout << dp[(1ll << n) - 1][0] << "\n";

#undef int
}
```

---

## 21. Counting Tilings

### Problem Statement & Core Idea
Count the number of ways to completely tile an $n \times m$ grid ($n \le 10, m \le 1000$) using $1 \times 2$ and $2 \times 1$ dominoes.
- **Broken Profile / Column Profile DP**: Process the grid column by column (or cell by cell), maintaining a bitmask of length $n$ describing which cells in column $j$ are already covered by horizontal dominoes extending from column $j - 1$.

![Counting Tilings Concept](images/21_counting_tilings.png)

### Formal DP Formulation

- **State Definition**:
  $$f(j, \text{mask}) = \text{ways to tile columns } 0..j-1 \text{ such that column } j \text{ has protrusion profile } \text{mask} \in [0, 2^n - 1]$$
  where bit $i$ of $\text{mask}$ is $1$ iff cell $(i, j)$ is covered by a $1 \times 2$ horizontal tile placed at $(i, j-1)$.

- **Base Case & Answer**:
  $$f(0, 0) = 1, \qquad \text{Answer} = f(m, 0)$$

---

### Method 1: Subset DP — $\mathcal{O}(m \cdot 3^n)$
- Given target `profile` for column $j$, let `prev_profile = ((1 << n) - 1) ^ profile` be the cells in column $j - 1$ that do **not** start a new horizontal tile.
- Iterate over all submasks `sub` of `prev_profile` (representing cells in column $j - 1$ already filled from column $j - 2$). The remaining cells `vertical = prev_profile ^ sub` must be tiled by $2 \times 1$ vertical dominoes (valid iff every contiguous run of $1$-bits in `vertical` has even length):
  $$f(j, \text{profile}) = \sum_{\substack{\text{sub} \subseteq \overline{\text{profile}} \\ \text{fillable}(\overline{\text{profile}} \oplus \text{sub})}} f(j - 1, \text{sub}) \pmod{10^9 + 7}$$

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n, m;
    cin >> n >> m;

    vector<int> cur(1ll << n, 0), next(1ll << n, 0);
    cur[0] = 1; // clean profile is 1 way

    // prcompute what masks are fillable by vertical cols
    // basically what bits are vertically fillable
    vector<bool> fillable(1ll << n, false);
    for (int mask = 0; mask < (1ll << n); mask++) {
        bool can = true;
        // idea is that seq of one bits should be even length
        int len = 0;
        for (int i = 0; i < n; i++) {
            if (mask & (1ll << i)) {
                len++;
            } else {
                if (len & 1) {
                    can = false;
                    break;
                }
                len = 0;
            }
        }
        // last seq
        if (len & 1)
            can = false;
        fillable[mask] = can;
    }

    const int mod = (int)1e9 + 7;

    for (int j = 0; j < m; j++) { // for each col
        fill(next.begin(), next.end(), 0);
        for (int profile = 0; profile < (1ll << n); profile++) { // for each profile
            int prev_profile = ((1ll << n) - 1) ^ profile;        // inverted

            for (int sub = prev_profile;; sub = (sub - 1) & prev_profile) {
                // submasks of prev_profile, what's not filled should be
                // fillable by vertical cols

                int vertical = prev_profile ^ sub;
                if (fillable[vertical]) {
                    (next[profile] += cur[sub]) %= mod;
                }

                // submask iteration that processes 0 submask too
                if (sub == 0)
                    break;
            }
        }
        cur.swap(next);
    }

    cout << cur[0] << "\n";

#undef int
}
```

---

### Method 2: Precomputed Column Transitions
- Recursively generate all valid `(left_mask, right_mask)` pairs across rows $0..n-1$ once, then transition in $\mathcal{O}(m \cdot |\text{trans}|)$:
  $$f(j, \text{right}) = \sum_{(\text{left}, \text{right}) \in \text{trans}} f(j - 1, \text{left}) \pmod{10^9 + 7}$$

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n, m;
    cin >> n >> m;

    vector<int> cur(1ll << n, 0), next(1ll << n, 0);
    cur[0] = 1; // clean profile is 1 way
    const int mod = 1e9 + 7;

    // precomp transitions that are valid ( left mask -> right mask )
    vector<pair<int, int>> trans;
    auto gen = [&](auto &&f, int row, int left, int right) -> void {
        if (row > n)
            return;
        if (row == n) {
            trans.emplace_back(left, right);
            return;
        };
        // 1 => is this filled by extension from prev col
        // 1x2 place, left 0, right filled by extension
        f(f, row + 1, left, right | (1ll << row));
        // another valid is when left acceps an extension, in this case right is 0
        // as we place a new 1x2 here
        f(f, row + 1, left | (1ll << row), right);
        // vertical 2x1, set both as 0
        f(f, row + 2, left, right);
    };
    gen(gen, 0, 0, 0);

    for (int j = 0; j < m; j++) { // for each col
        fill(next.begin(), next.end(), 0);
        for (auto &[left, right] : trans) {
            (next[right] += cur[left]) %= mod;
        }
        swap(cur, next);
    }

    cout << cur[0] << "\n";

#undef int
}
```

---

### Method 3: True Broken Profile (Cell-by-Cell) — $\mathcal{O}(nm \cdot 2^n)$
- Advance cell $(i, j)$ one by one. At cell $(i, j)$:
  - If bit $i$ of `mask` is $1$ (`blocked`): cell $(i, j)$ is already covered; clear bit $i$ (`next_mask = mask ^ (1 << i)`).
  - If bit $i$ of `mask` is $0$ (empty):
    1. **Place Horizontal $1 \times 2$**: set bit $i$ to $1$ (`mask | (1 << i)`) so column $j + 1$ knows cell $(i, j+1)$ is covered.
    2. **Place Vertical $2 \times 1$** (if $i + 1 < n$ and bit $i + 1$ is $0$): leave bit $i$ as $0$ and set bit $i + 1$ to $1$ (`mask | (1 << (i + 1))`) so the next row step skips $(i+1, j)$.

```c++
#include <bits/stdc++.h>
using namespace std;

int main() {
#define int long long
    int n, m;
    cin >> n >> m;

    vector<int> cur(1ll << n, 0), next(1ll << n, 0);
    cur[0] = 1;

    const int mod = 1e9 + 7;

    for (int j = 0; j < m; j++) {
        for (int i = 0; i < n; i++) {
            fill(next.begin(), next.end(), 0);
            for (int mask = 0; mask < (1ll << n); mask++) {
                if (!cur[mask]) // not reachable
                    continue;

                // blocked => next is filled via col-1 (cur)
                // so 1 here = do I fill next col too?
                bool blocked = (mask & (1ll << i)) != 0;
                if (blocked) {
                    int next_mask = mask ^ (1ll << i); // must be 0
                    (next[next_mask] += cur[mask]) %= mod;
                } else {
                    // two choices, place vertical or horizontal

                    // horizontal
                    int next_mask = mask | (1ll << i); // next mask if filled by col-1, aka cur
                    (next[next_mask] += cur[mask]) %= mod;

                    // cur is a valid mask for vertical placement
                    if (i + 1 < n && (mask & (1ll << (i + 1))) == 0) {
                        next_mask = mask; // it isn't filled at all
                        // i+1 needs to be marked as filled so that loop
                        // skips it
                        next_mask |= (1ll << (i + 1));
                        (next[next_mask] += cur[mask]) %= mod;
                    }
                }
            }
            cur.swap(next);
        }
    }

    cout << cur[0] << "\n";

#undef int
}
```

---

## 22. Counting Numbers

### Problem Statement & Core Idea
Count the number of integers in $[a, b]$ ($0 \le a \le b \le 10^{18}$) such that no two adjacent digits are equal.
- **Digit DP**: Compute $f(b) - f(a - 1)$, where $f(x)$ counts valid integers in $[0, x]$ by building the number from most-significant digit to least-significant digit with state $(\text{pos}, \text{tight}, \text{lz}, \text{prev})$.

![Counting Numbers Concept](images/22_counting_numbers.png)

### Formal DP Formulation

- **State Parameters**:
  - $\text{pos}$: current digit index ($0 \dots |s|-1$).
  - $\text{tight} \in \{0, 1\}$: whether the prefix matches the upper bound prefix of $s$.
  - $\text{lz} \in \{0, 1\}$: whether all digits placed so far are leading zeros.
  - $\text{prev} \in \{0, \dots, 9\}$: digit placed at $\text{pos} - 1$.

- **State Transition**:
  Let $\text{limit} = \text{tight} ? (s[\text{pos}] - \text{'0'}) : 9$. Then:
  $$\text{dp}(\text{pos}, \text{tight}, \text{lz}, \text{prev}) = \sum_{\substack{d = 0 \\ \neg(\text{!new\_lz} \land d = \text{prev})}}^{\text{limit}} \text{dp}\big(\text{pos} + 1,\; \text{tight} \land (d = \text{limit}),\; \text{lz} \land (d = 0),\; d\big)$$

### General Digit DP Template

```c++
int dp(int pos, bool tight, bool lz, int state) {
    if (pos == S.size()) return 1;
    if (MEMO[pos][tight][lz][state] != -1) return MEMO[pos][tight][lz][state];

    int limit = tight ? (S[pos] - '0') : 9;
    int ans = 0;

    for (int digit = 0; digit <= limit; digit++) {
        bool new_tight = tight && (digit == limit);
        bool new_lz = lz && (digit == 0);

        int new_state = state;
        if (!new_lz) {
            // new_state update logic
        }

        ans += dp(pos + 1, new_tight, new_lz, new_state);
    }

    return MEMO[pos][tight][lz][state] = ans;
}
```

### Complete Solution Code

```c++
#include <bits/stdc++.h>
using namespace std;

#define int long long

int MEMO[20][2][2][10];
string s;

int dp(int pos, bool tight, bool lz, int prev) {
    if (pos == (int)s.size())
        return 1;
    if (MEMO[pos][tight][lz][prev] != -1)
        return MEMO[pos][tight][lz][prev];

    int limit = tight ? (s[pos] - '0') : 9;
    int ans = 0;

    for (int digit = 0; digit <= limit; digit++) {
        bool new_tight = tight && (digit == limit);
        bool new_lz = lz && (digit == 0);

        // !new_lz => I placed some digit that makes it non leading zero
        if (digit == prev && !new_lz)
            continue;
        ans += dp(pos + 1, new_tight, new_lz, digit);
    }

    return MEMO[pos][tight][lz][prev] = ans;
}

signed main() {
    int a, b;
    cin >> a >> b;

    auto f = [&](int x) {
        if (x < 0)
            return 0ll;
        if (x == 0)
            return 1ll;
        s = to_string(x);
        memset(MEMO, -1, sizeof(MEMO));
        return dp(0, 1, 1, 0);
    };

    cout << f(b) - f(a - 1) << "\n";
}
```

---

## 23. Increasing Subsequences 2

### Problem Statement & Core Idea
Count the total number of strictly increasing subsequences in an array $a_1, \dots, a_n$ modulo $10^9 + 7$.
- Unlike LIS length which takes $\max$, counting takes the **sum** over all valid predecessors: $1 + \sum_{j < i,\; a_j < a_i} f(j)$.
- **Coordinate Compression + Fenwick Tree (BIT)**: Compress array values into $\{0, \dots, U-1\}$ (order relationships are preserved) and maintain prefix sums dynamically in $\mathcal{O}(n \log n)$.

![Increasing Subsequences 2 Concept](images/23_increasing_subsequences_2.png)

### Formal DP Formulation

- **State Definition**:
  $$f(i) = \text{number of strictly increasing subsequences ending at index } i$$

- **Base Case**:
  Each element forms a valid length-$1$ subsequence by itself ($+1$).

- **State Transition**:
  $$f(i) = \left( 1 + \sum_{j < i,\; a_j < a_i} f(j) \right) \bmod (10^9 + 7) = \big(1 + \text{BIT.sum}(v_i - 1)\big) \bmod (10^9 + 7)$$
  $$	ext{Total Answer} = \left( \sum_{i=0}^{n-1} f(i) \right) \bmod (10^9 + 7)$$

- **Coordinate Compression Steps**: Copy array $\to$ `sort` $\to$ `erase(unique(...))` $\to$ replace each element with its `lower_bound` rank.

```c++
#include <bits/stdc++.h>
using namespace std;

#define int long long

signed main() {
    int n;
    cin >> n;
    vector<int> v(n);
    for (int &x : v)
        cin >> x;

    // cnt doesn't change on compression
    auto compress = [&](vector<int> &arr) {
        vector<int> sorted = arr;
        sort(sorted.begin(), sorted.end());
        sorted.erase(unique(sorted.begin(), sorted.end()), sorted.end());
        for (int &x : arr) {
            x = lower_bound(sorted.begin(), sorted.end(), x) - sorted.begin();
        }
    };
    compress(v);

    const int mod = 1e9 + 7;
    vector<int> ft(n + 1, 0);
    auto add = [&](int i, int val) {
        for (++i; i <= n; i += i & -i)
            (ft[i] += val) %= mod;
    };
    auto sum = [&](int i) {
        int res = 0;
        for (++i; i > 0; i -= i & -i)
            (res += ft[i]) %= mod;
        return res;
    };

    int ans = 0;
    for (int i = 0; i < n; i++) {
        int less = sum(v[i] - 1);
        (ans += 1 + less) %= mod;
        add(v[i], 1 + less);
    }

    cout << ans << '\n';
}
```
